import shutil
shutil.make_archive("Mihail_Todorov99_Error_Handling_Homework", 'zip',
                    "C:/MISHOMISHO/PYTHON/Softuni_Advanced_2022/Advanced/Python_Advanced/05_Error_Handling_Homework")